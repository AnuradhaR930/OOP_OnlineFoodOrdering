--> Technologies Used - 

1. JSP
2. Servlets
3. Hibernate
4. Mysql Database


-->> Project Requirements -

1. Java 
2. Apache Tomcat Server 
3. Mysql Database
4. Eclipse
